import React from 'react'
import Section from './Section'
import Card from '../UI/card'
import { testimonials } from '../../data'
import {ImQuotesLeft} from 'react-icons/im'

const Testimonials = () => {
  return (
    <div>Testimonials</div>
  )
}

export default Testimonials