import React from 'react'
import './about.css'
const About = () => {
  return (
    <div>about</div>
  )
}

export default About