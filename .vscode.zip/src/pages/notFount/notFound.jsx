import React from 'react'
import './notFound.css'
const NotFount = () => {
  return (
    <div>notFount</div>
  )
}

export default NotFount