import React from 'react'
import './gallary.css'
const Gallary = () => {
  return (
    <div>gallary</div>
  )
}

export default Gallary