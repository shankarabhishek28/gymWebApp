import React from 'react'
import './plans.css'
const Plans = () => {
  return (
    <div>plans</div>
  )
}

export default Plans