import React from 'react'
import './trainers.css'
const Trainers = () => {
  return (
    <div>trainers</div>
  )
}

export default Trainers